# CIS1500-O1531-Summer2021-Project0

Write a Java application that outputs the following information using print line statements:

Your name

Your preferred pronouns

Your program/major

Your reason for taking this course

What you hope to get out of the course ( it's ok if the answer is just a passing score for transfer credit )

Anything else you'd like me to know about you
