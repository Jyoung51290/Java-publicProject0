/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hellow0rld;

/**
 *
 * @author Jake
 */
public class HelloW0rld {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("Jake Young");
        System.out.println("He/Him/His");
        System.out.println("Software Engineering");
        System.out.println("I am taking this class to see if I will like coding and to get my degree if I do like it");
        System.out.println("A passion for coding to do it for a living");
        System.out.println("I am a nerd that pretty much only games and watches anime although I like sports too and do not really have friends");
    }
    
}
